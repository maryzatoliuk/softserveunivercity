/* Type in Motion — website hero
   1. Intro: the headline lines swing in like doors (the "Swinging headline" variant), staggered.
   2. Scroll: the panel starts tilted back in 3D and straightens as you scroll;
      each headline line also drifts sideways at its own speed (parallax), so the type feels like it is in space.
   3. Courses: cards flip down from the top edge (like the "Flip words" prisms) as the grid comes into view. */
(function(){
  const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const hero=document.getElementById('hero'), panel=document.getElementById('panel');
  const lines=[...document.querySelectorAll('.hl')];
  const clamp=v=>v<0?0:v>1?1:v;
  const outCubic=k=>1-Math.pow(1-k,3), inOut=k=>k<.5?4*k*k*k:1-Math.pow(-2*k+2,3)/2;

  const T0=performance.now();
  const INTRO=1.6, STAG=.14;        // seconds
  let sp=0, target=0;               // smoothed scroll progress 0..1

  function frame(now){
    const t=Math.max(0,(now-T0)/1000);
    const r=hero.getBoundingClientRect();
    target=clamp(-r.top/(innerHeight*.9));
    sp+= (target-sp)*.12;           // ease the scroll so the 3D move feels like a camera, not a jump

    // panel: tilted back (and a bit lower/smaller) at the top of the page → flat as you scroll
    const intro=reduce?1:outCubic(clamp(t/1.2));
    const tilt=(1-sp)*14+(1-intro)*30;
    const s=.9+.1*sp, y=(1-sp)*40+(1-intro)*120;
    panel.style.transform=`translateY(${y.toFixed(1)}px) rotateX(${tilt.toFixed(2)}deg) scale(${s.toFixed(4)})`;

    // headline lines: swing in on load, then drift with scroll
    lines.forEach((el,i)=>{
      const k=reduce?1:inOut(clamp((t-.35-i*STAG)/(INTRO-.6)));
      const ry=-80*(1-k);                                   // door: from turned-away to flat
      const dx=(+el.dataset.speed)*sp*innerWidth;           // parallax drift while scrolling
      el.style.transform=`translateX(${dx.toFixed(1)}px) rotateY(${ry.toFixed(2)}deg)`;
      el.style.opacity=(k<.15?k/.15:1).toFixed(3);
    });
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // top bar gets a background once the courses scroll under it
  const bar=document.querySelector('.bar'), courses=document.getElementById('courses');
  addEventListener('scroll',()=>bar.classList.toggle('solid',courses.getBoundingClientRect().top<70),{passive:true});

  // courses: flip-in, row by row
  const cards=[...document.querySelectorAll('.card')];
  const io=new IntersectionObserver(es=>es.forEach(e=>{
    if(!e.isIntersecting) return;
    const i=cards.indexOf(e.target);
    e.target.style.transitionDelay=((i%3)*.09+Math.floor(i/3)*.05)+'s';
    e.target.classList.add('in'); io.unobserve(e.target);
  }),{threshold:.15});
  cards.forEach(c=>io.observe(c));

  // cards lean slightly towards the cursor
  cards.forEach(c=>{
    c.addEventListener('pointermove',e=>{
      if(!c.classList.contains('in')) return;
      const r=c.getBoundingClientRect(), x=(e.clientX-r.left)/r.width-.5, y=(e.clientY-r.top)/r.height-.5;
      c.style.transitionDelay='0s';
      c.style.transform=`rotateX(${(-y*8).toFixed(2)}deg) rotateY(${(x*10).toFixed(2)}deg) translateZ(0)`;
    });
    c.addEventListener('pointerleave',()=>{ c.style.transform=''; });
  });
})();
