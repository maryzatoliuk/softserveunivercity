/* Type in Motion — website hero, "angled camera" version (like story variant 05)
   The poster is flat; a camera slowly orbits it — left/right AND up/down — pausing on each angle.
   The headline sits on its own plane, lifted towards the camera and tilted a little, so it peels off the poster.
   The pointer nudges the camera too; scrolling lays the poster back as the courses come up. */
(function(){
  const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const hero=document.getElementById('hero'), rig=document.getElementById('rig'), title=document.getElementById('tplane'), oval=document.querySelector('.oval');
  const clamp=v=>v<0?0:v>1?1:v, sine=k=>-(Math.cos(Math.PI*k)-1)/2, outCubic=k=>1-Math.pow(1-k,3);
  const STOPS=[[-1,.5],[1,-.35],[.6,.6],[-.75,-.45]], HOLD=1.4, MOVE=3.0, SEG=HOLD+MOVE, A=11;   // A = max angle, deg
  const T0=performance.now();
  let px=0,py=0,mx=0,my=0,sp=0;
  addEventListener('pointermove',e=>{px=e.clientX/innerWidth-.5; py=e.clientY/innerHeight-.5;},{passive:true});
  function frame(now){
    const t=Math.max(0,(now-T0)/1000), CY=SEG*STOPS.length, k=t%CY, i=Math.floor(k/SEG), l=k-i*SEG, a=STOPS[i], b=STOPS[(i+1)%STOPS.length];
    const e=reduce?0:(l<HOLD?0:sine((l-HOLD)/MOVE));
    mx+=(px-mx)*.06; my+=(py-my)*.06;
    const r=hero.getBoundingClientRect(); sp+=(clamp(-r.top/(innerHeight*.6))-sp)*.12;
    const intro=reduce?1:outCubic(clamp(t/1.4));
    const yaw=reduce?0:A*(a[0]+(b[0]-a[0])*e)+mx*8, pitch=reduce?0:A*.7*(a[1]+(b[1]-a[1])*e)-my*6;
    rig.style.transform=`translateY(${((1-intro)*80).toFixed(1)}px) scale(${(.96-.06*sp).toFixed(4)}) rotateX(${(-pitch+sp*22+(1-intro)*25).toFixed(2)}deg) rotateY(${(-yaw).toFixed(2)}deg)`;
    title.style.transform=`translateZ(${(60+30*(1-intro)).toFixed(1)}px) rotateY(${(9+2*Math.sin(t*.37)).toFixed(2)}deg) rotateX(${(-6+1.2*Math.sin(t*.29)).toFixed(2)}deg) rotateZ(-1.6deg)`;
    oval.style.transform=`translate(${(-yaw*1.6).toFixed(1)}px,${(pitch*1.6).toFixed(1)}px)`;
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // top bar gets a background once the courses scroll under it
  const bar=document.querySelector('.bar'), courses=document.getElementById('courses');
  addEventListener('scroll',()=>bar.classList.toggle('solid',courses.getBoundingClientRect().top<70),{passive:true});

  // courses: flip-in, row by row
  const cards=[...document.querySelectorAll('.card')];
  const io=new IntersectionObserver(es=>es.forEach(e=>{
    if(!e.isIntersecting) return;
    const i=cards.indexOf(e.target);
    e.target.style.transitionDelay=((i%3)*.09+Math.floor(i/3)*.05)+'s';
    e.target.classList.add('in'); io.unobserve(e.target);
  }),{threshold:.15});
  cards.forEach(c=>io.observe(c));

  // cards lean slightly towards the cursor
  cards.forEach(c=>{
    c.addEventListener('pointermove',e=>{
      if(!c.classList.contains('in')) return;
      const r=c.getBoundingClientRect(), x=(e.clientX-r.left)/r.width-.5, y=(e.clientY-r.top)/r.height-.5;
      c.style.transitionDelay='0s';
      c.style.transform=`rotateX(${(-y*8).toFixed(2)}deg) rotateY(${(x*10).toFixed(2)}deg) translateZ(0)`;
    });
    c.addEventListener('pointerleave',()=>{ c.style.transform=''; });
  });
})();
