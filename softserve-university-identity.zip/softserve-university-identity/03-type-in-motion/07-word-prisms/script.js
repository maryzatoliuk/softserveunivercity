/* 07 — Word prisms. Edit MSGS: [text, font-size] per line. */
/* ---------- Є. Word prisms ---------- */
(function(){
  const frame=document.getElementById('prismFrame'), bar=document.getElementById('barR');
  const MSGS=[
    [['{logo}',34]],                       // {logo} = SoftServe University logo as one prism face
    [['70+ IT',72],['courses',72]],
    [['for every',54],['level and',54],['goal',54]],
    [['Since',86],['2005',86]],
    [['36 000+',62],['graduates',52]],
  ];
  const msgs=MSGS.map(lines=>{
    const m=document.createElement('div'); m.className='msg'; const words=[];
    let H=0; lines.forEach(([txt,size])=>{
      const l=document.createElement('div'); l.className='pline'; l.style.fontSize=size+'px'; l.style.lineHeight=(size*.92)+'px'; l.style.height=(size*.92)+'px';
      (txt==='{logo}'?[txt]:txt.split(' ')).forEach(w=>{const s=document.createElement('span'); s.className='pw';
        if(w==='{logo}') s.innerHTML='<img src="../assets/softserve-university-logo.png" alt="SoftServe University" style="height:'+(size*.85)+'px;display:block;margin-top:'+(size*.035)+'px">'; else s.textContent=w;
        s.style.transformOrigin=`50% 50% ${-(size*.46).toFixed(1)}px`; l.appendChild(s); words.push(s);});
      m.appendChild(l); H+=size*.92;
    });
    m.style.marginTop=(-H/2)+'px'; frame.insertBefore(m,frame.firstChild); return {m,words};
  });
  const HOLD=1.6, TRANS=1.2, CYC=HOLD+TRANS, STAG=.07, DUR=.6;
  const ease=k=>k<.5?4*k*k*k:1-Math.pow(-2*k+2,3)/2, clamp=v=>v<0?0:v>1?1:v;
  function loop(){
    const t=window.__t||0, n=Math.floor(t/CYC), l=t-n*CYC, cur=n%msgs.length, nxt=(n+1)%msgs.length;
    const p=l-HOLD;
    msgs.forEach((M,mi)=>{
      if(mi!==cur&&!(mi===nxt&&p>0)){M.m.style.display='none';return;}
      M.m.style.display='block';
      M.words.forEach((w,i)=>{
        let a, op=1;
        if(mi===cur){                                               // old face: rolls down fast and fades
          const k=p>0?clamp((p-i*.03)/.32):0;
          a=-90*k*k; op=1-clamp(k*1.6);
        } else {                                                    // new face: comes from the top once the old one is gone
          const k=ease(clamp((p-.15-i*STAG)/DUR));
          a=90-90*k; op=clamp(k*2.5);
        }
        w.style.visibility=(Math.abs(a)>=89.9||op<=.01)?'hidden':'visible';
        w.style.opacity=op.toFixed(3);
        w.style.transform=`rotateX(${a.toFixed(2)}deg)`;
      });
    });
    bar.style.width=((t%(CYC*msgs.length))/(CYC*msgs.length)*100)+'%';
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
})();
