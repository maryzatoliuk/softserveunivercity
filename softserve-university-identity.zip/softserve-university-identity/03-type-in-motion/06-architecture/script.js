/* 06 — handheld lateral dolly; .ftext elements float at data-z in front of the photo */
(function(){
  const frame=document.getElementById('facadeFrame'), cam=document.getElementById('cam');
  const grain=document.getElementById('grain'), bar=document.getElementById('barB');
  frame.querySelectorAll('.ftext').forEach(el=>{
    const z=+el.dataset.z;
    el.style.transform=el.classList.contains('floor')?`translateZ(${z}px) rotateX(58deg)`:`translateZ(${z}px) rotateY(8deg)`;
  });
  let n=0;
  function loop(){
    const t=window.__t||0;
    // slow lateral dolly past the text (like the first reference) + handheld micro-shake
    const sw=Math.sin(t*.32);
    const ry=-7*sw+.3*Math.sin(t*2.1)+.18*Math.sin(t*3.7);
    const rx=1.5+1.2*Math.sin(t*.21)+.2*Math.sin(t*2.7);
    const tx=62*sw+1.5*Math.sin(t*3.3);
    const ty=6*Math.sin(t*.17)+2*Math.sin(t*3.1);
    const tzc=20+40*Math.sin(t*.19);
    cam.style.transform=`translate3d(${tx}px,${ty}px,${tzc}px) rotateX(${rx}deg) rotateY(${ry}deg)`;
    bar.style.width=((t%16)/16*100)+'%';
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
  const ib=document.getElementById('integ'); if(ib) ib.onclick=e=>{const raw=frame.classList.toggle('raw');e.target.textContent=raw?'Інтеграція: вимк.':'Інтеграція: увімк.';e.target.classList.toggle('on',!raw);};
})();
