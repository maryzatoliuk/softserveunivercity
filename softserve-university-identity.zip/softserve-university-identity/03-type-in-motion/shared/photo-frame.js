/* Photo-in-space frames (02, 04): background plate, cut-out figure, headline lines woven between them.
   cfg: frame id, camera stops [[yaw,pitch],...], tiltX/tiltZ of the lines, bob (px the figure floats), offset (s).

   The scene is built from separate layers, painted in this order (all share one camera transform):
     1. .pback        background photo (figure removed)
     2. back lines    lines with data-z < 0 (they stay behind the person for the whole loop)
     3. figure        the cut-out person
     4. front lines   lines with data-z >= 0, and the small front text (.pfront)
   Keeping the person in its own layer means text can never cut through it. The loop length equals the
   camera path (all stops) and both headline sets, so the last frame matches the first one. */
function initPhotoFrame(cfg){
  const frame=document.getElementById(cfg.frame);
  const back=frame.querySelector('.pback'), scene=frame.querySelector('.pscene:not(.pback)');
  const bar=frame.querySelector('.story-ui .bar i'), fig=frame.querySelector('.pfig');
  const TILT_X=cfg.tiltX, TILT_Z=cfg.tiltZ;

  // --- build layers ---
  const mk=()=>{const d=document.createElement('div'); d.className='pscene'; return d;};
  const backLines=mk(), figLayer=mk();
  scene.before(backLines); scene.before(figLayer); figLayer.appendChild(fig);
  const layers=[back,backLines,figLayer,scene].filter(Boolean);

  // every line keeps its depth for the whole loop: data-z < 0 → behind the person, otherwise in front.
  // No copies and no cross-fades, so a line never "jumps" from one side of the person to the other mid-turn.
  const lines=[...scene.querySelectorAll('.pl')].map(el=>{
    const L={el,s:+el.dataset.s,z:+el.dataset.z,x:+el.dataset.x,y:+el.dataset.y};
    if(L.z<0) backLines.appendChild(el);
    return L;
  });
  lines.forEach(L=>{L.i=lines.filter(o=>o.s===L.s).indexOf(L);});

  const clamp=v=>v<0?0:v>1?1:v, sine=k=>-(Math.cos(Math.PI*k)-1)/2, ease=k=>k<.5?4*k*k*k:1-Math.pow(-2*k+2,3)/2, smooth=k=>k*k*(3-2*k);
  const STOPS=cfg.stops, H=1.6, M=2.6, SEG=H+M;
  // one loop = the camera visiting every stop = two headline sets → the end frame equals the start frame
  const CY=SEG*STOPS.length, CYCLE=CY/2, TRANS=2.2, HOLD=CYCLE-TRANS, OUT_MAX=70, IN_MAX=66, STAG=.1, D=.5, IN_AT=.3;

  const show=(el,tf,origin,op)=>{
    if(op<=.004){ if(el.__v!==0){el.style.visibility='hidden'; el.__v=0;} return; }
    if(el.__v!==1){el.style.visibility='visible'; el.__v=1;}
    el.style.transformOrigin=origin; el.style.transform=tf; el.style.opacity=op.toFixed(3);
  };
  const place=(L,theta,origin,op)=>show(L.el,`translate3d(${L.x}px,${L.y}px,${L.z}px) rotateX(${TILT_X}deg) rotateZ(${TILT_Z}deg) rotateY(${theta.toFixed(3)}deg)`,origin,op);

  function loop(){
    const t=(window.__t||0)+(cfg.offset||0);
    const k=((t%CY)+CY)%CY, i=Math.floor(k/SEG), l=k-i*SEG, a=STOPS[i], b=STOPS[(i+1)%STOPS.length];
    const e=l<H?0:sine((l-H)/M);
    const camT=`translateZ(-30px) rotateX(${(a[1]+(b[1]-a[1])*e).toFixed(3)}deg) rotateY(${(a[0]+(b[0]-a[0])*e).toFixed(3)}deg)`;
    layers.forEach(ly=>ly.style.transform=camT);
    // the figure floats a whole number of times per loop, so the loop has no seam
    if(cfg.bob&&fig) fig.style.transform=`translateY(${(cfg.bob*Math.sin(k/CY*Math.PI*2*4)).toFixed(2)}px)`;

    const c=Math.floor(k/CYCLE), loc=k-c*CYCLE, cur=c%2;
    const p=loc<HOLD?0:(loc-HOLD)/TRANS;
    lines.forEach(L=>{
      if(L.s===cur){
        if(p===0){ place(L,0,'100% 50%',1); return; }
        const q=ease(clamp((p-L.i*STAG)/D));                          // swing away into depth, pivot on the right edge
        place(L,-OUT_MAX*q,'100% 50%',1-smooth(clamp((q-.45)/.55)));
      } else if(p>0){
        const q=ease(clamp((p-IN_AT-L.i*STAG)/D));                    // swing back from depth, pivot on the left edge — done before the set holds
        place(L,IN_MAX*(1-q),'0% 50%',smooth(clamp(q/.35)));
      } else place(L,IN_MAX,'0% 50%',0);
    });
    bar.style.width=(k/CY*100).toFixed(2)+'%';
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
}
