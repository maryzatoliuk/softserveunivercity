/*
  Shared clock for all variants.
  Every animation reads window.__t (seconds, already multiplied by speed and frozen on pause)
  and window.__blur (false when motion blur is off or the clock is paused).
  Buttons with ids pause / slow / blur are wired automatically if they exist on the page.
*/
(function(){
  // Safari repaints CSS blur filters on every frame, which makes motion stutter → start with blur off there
  const isSafari=/^((?!chrome|android|crios|fxios).)*safari/i.test(navigator.userAgent);
  let t=0, last=null, paused=false, speed=1, blur=!isSafari, visible=true;
  // ?embed → frame only (used by the overview page, index.html)
  if(/[?&]embed/.test(location.search)) document.documentElement.classList.add('embed');
  document.documentElement.classList.toggle('is-safari',isSafari);
  function tick(now){
    if(last===null) last=now;
    const raw=Math.min((now-last)/1000,.05); last=now;
    if(!paused&&visible) t+=raw*speed;
    window.__t=t; window.__blur=blur&&!paused;
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
  window.__setT=v=>{t=v;};
  // commands from the overview page: {kt:'pause'|'speed'|'blur'|'integ'|'visible', value}
  window.addEventListener('message',e=>{
    const d=e.data||{}; if(!d.kt) return;
    if(d.kt==='pause') paused=!!d.value;
    if(d.kt==='speed') speed=+d.value||1;
    if(d.kt==='blur') blur=!!d.value;
    if(d.kt==='visible') visible=!!d.value;
    if(d.kt==='integ') document.querySelectorAll('#facadeFrame,#atriumFrame').forEach(f=>f.classList.toggle('raw',!d.value));
  });            // handy for debugging: jump to a moment
  const on=(id,fn)=>{const b=document.getElementById(id); if(b) b.addEventListener('click',fn);};
  on('pause',e=>{paused=!paused;e.target.textContent=paused?'Грати':'Пауза';e.target.classList.toggle('on',paused);});
  on('slow',e=>{speed=speed===1?.35:1;e.target.classList.toggle('on',speed!==1);});
  const bb=document.getElementById('blur'); if(bb&&!blur){bb.textContent='Motion blur: вимк.';bb.classList.remove('on');}
  on('blur',e=>{blur=!blur;e.target.textContent='Motion blur: '+(blur?'увімк.':'вимк.');e.target.classList.toggle('on',blur);});
})();
