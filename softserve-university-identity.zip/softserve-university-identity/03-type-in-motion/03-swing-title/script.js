/* 02 — Swinging title. Timing: HOLD / TRANS / STAG; angles: OUT_MAX / IN_MAX */
(function(){
  const PERSP=440, frame=document.getElementById('swing'), bar=document.getElementById('barS');
  const pages=[...frame.querySelectorAll('.page')];
  const lines=[...frame.querySelectorAll('.line')].map(el=>({el,p:+el.dataset.p,w:0,prev:0,b:0}));
  const NP=pages.length;
  lines.forEach(L=>{L.i=lines.filter(o=>o.p===L.p).indexOf(L);});
  const measure=()=>lines.forEach(L=>L.w=L.el.offsetWidth);
  measure(); if(document.fonts) document.fonts.ready.then(measure);

  const HOLD=2.2, TRANS=2.3, CYCLE=HOLD+TRANS, OUT_MAX=74, IN_MAX=72, STAG=.09;
  const clamp=v=>v<0?0:v>1?1:v;
  const outCubic=k=>1-Math.pow(1-k,3), inOut=k=>k<.5?4*k*k*k:1-Math.pow(-2*k+2,3)/2;
  let lastT=null;
  const setBlur=(el,o,b)=>{const q=b>.12?Math.round(b*8)/8:0; if(q!==o.fq){o.fq=q; el.style.filter=q?`blur(${q}px)`:'none';}};


  function setLine(L,theta,origin,tx,op,dt){
    const zNear=L.w*Math.sin(Math.abs(theta)*Math.PI/180);
    if(op<=0.01 || zNear>PERSP-18){ L.el.style.visibility='hidden'; L.prev=theta; return; }
    L.el.style.visibility='visible';
    L.el.style.transformOrigin=origin;
    L.el.style.transform=`translateX(${tx.toFixed(1)}px) rotateY(${theta.toFixed(2)}deg)`;
    L.el.style.opacity=op.toFixed(3);
    // soft blur: grows with angular speed AND with how far the line has turned, eased over time
    const w=dt>0?Math.abs(theta-L.prev)/dt:0; L.prev=theta;
    const turn=Math.min(1,Math.max(0,(Math.abs(theta)-12)/40));
    const target=(window.__blur!==false&&dt>0)?Math.min(1.4,w/170)*turn*turn:0;
    L.b+=(target-L.b)*Math.min(1,dt*7);
    setBlur(L.el,L,L.b);
  }

  function loop(){
    const t=window.__t||0, dt=lastT===null?0:Math.max(0,t-lastT); lastT=t;
    const W=frame.clientWidth;
    const n=Math.floor(t/CYCLE), local=t-n*CYCLE, cur=n%NP, nxt=(n+1)%NP;
    const p=local<HOLD?0:(local-HOLD)/TRANS;
    const slide=inOut(clamp((p-.12)/.76));
    pages.forEach((pg,j)=>{
      if(j===cur){ pg.style.visibility='visible'; pg.style.transform=`translateX(${(-W*slide).toFixed(1)}px)`; }
      else if(j===nxt && p>0){ pg.style.visibility='visible'; pg.style.transform=`translateX(${(W*(1-slide)).toFixed(1)}px)`; }
      else pg.style.visibility='hidden';
    });
    lines.forEach(L=>{
      if(L.p===cur){
        if(p===0){ setLine(L,0,'100% 50%',0,1,dt); return; }
        const k=clamp((p-L.i*STAG)/.42);               // swing away, pivot on the right edge
        setLine(L,OUT_MAX*(1-Math.cos(k*Math.PI/2)),'100% 50%',-W*.35*slide,k<.7?1:Math.pow(1-(k-.7)/.3,1.5),dt);
      } else if(L.p===nxt && p>0){
        const k=clamp((p-.44-L.i*STAG)/.5);            // swing in, pivot on the left edge
        setLine(L,-IN_MAX*(1-outCubic(k)),'0% 50%',W*.25*(1-slide),k>0?(k<.1?k/.1:1):0,dt);
      } else setLine(L,0,'0% 50%',0,0,dt);
    });
    bar.style.width=((t%(CYCLE*NP))/(CYCLE*NP)*100)+'%';
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
})();
