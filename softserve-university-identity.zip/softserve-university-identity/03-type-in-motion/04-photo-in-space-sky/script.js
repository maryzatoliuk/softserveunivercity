initPhotoFrame({frame:'skyFrame',stops:[[9,-5],[-10,4],[-5,-6],[8,5]],tiltX:-12,tiltZ:4,bob:3,offset:1.7});
