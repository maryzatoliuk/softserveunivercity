/* 03 — Angled camera (CSS 3D, no WebGL).
   The whole poster (rig) is turned the opposite way to where the camera "walks", so it reads as an orbiting camera.
   STOPS = [yaw, pitch] as a share of the "Кут" slider; HOLD = pause on each angle, MOVE = glide time.
   The headline lives on its own plane (#aTitle) lifted 34px towards the camera and tilted a little. */
(function(){
  const rig=document.getElementById('aRig'), title=document.getElementById('aTitle');
  const amt=document.getElementById('warpAmt'), bar=document.getElementById('barD');
  const sine=k=>-(Math.cos(Math.PI*k)-1)/2, DEG=180/Math.PI;
  const STOPS=[[-1,.5],[1,-.35],[.6,.6],[-.75,-.45]], HOLD=1.2, MOVE=2.6, SEG=HOLD+MOVE;
  function loop(){
    const t=window.__t||0, A=+amt.value, CY=SEG*STOPS.length, k=t%CY;
    const i=Math.floor(k/SEG), l=k-i*SEG, a=STOPS[i], b=STOPS[(i+1)%STOPS.length];
    const e=l<HOLD?0:sine((l-HOLD)/MOVE);
    const yaw=A*(a[0]+(b[0]-a[0])*e), pitch=A*.75*(a[1]+(b[1]-a[1])*e), zoom=1.03+.03*Math.sin(t*.3);
    rig.style.transform=`scale(${zoom.toFixed(4)}) rotateX(${(-pitch).toFixed(2)}deg) rotateY(${(-yaw).toFixed(2)}deg)`;
    const ty=(.17+.03*Math.sin(t*.37))*DEG, tp=(-.11+.02*Math.sin(t*.29))*DEG;
    title.style.transform=`translateZ(34px) rotateY(${ty.toFixed(2)}deg) rotateX(${tp.toFixed(2)}deg) rotateZ(-2deg)`;
    bar.style.width=(k/CY*100)+'%';
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
})();
