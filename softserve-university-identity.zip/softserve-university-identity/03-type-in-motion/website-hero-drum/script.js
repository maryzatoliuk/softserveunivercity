/* Type in Motion — website hero, "course drum" version
   Screen 1: the headline lines rise up into place (they turn in on the X axis).
   Screen 2: courses sit around a horizontal cylinder. Scrolling turns it: the course on the front
   is black and full size, the ones above and below fade to grey and squash as they roll away —
   like the client list on sturdy.co. The details row under the drum follows the active course. */
(function(){
  const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const clamp=v=>v<0?0:v>1?1:v, outCubic=k=>1-Math.pow(1-k,3);

  // --- screen 1 intro ---
  const lines=[...document.querySelectorAll('.big-title span')], T0=performance.now();
  function intro(now){
    const t=Math.max(0,(now-T0)/1000); let done=true;
    lines.forEach((el,i)=>{
      const k=reduce?1:outCubic(clamp((t-.15-i*.14)/1));
      if(k<1) done=false;
      el.style.transform=`translateY(${((1-k)*40).toFixed(1)}px) rotateX(${(-75*(1-k)).toFixed(2)}deg)`;
      el.style.opacity=k.toFixed(3);
    });
    if(!done) requestAnimationFrame(intro);
  }
  requestAnimationFrame(intro);

  // --- screen 2 drum ---
  const wrap=document.getElementById('courses'), items=[...document.querySelectorAll('.item')], N=items.length;
  const STEP=21;                                   // degrees between neighbouring courses
  const grey=[195,198,204], ink=[17,17,17];
  const dLang=document.getElementById('dLang'), dDates=document.getElementById('dDates'), dNum=document.getElementById('dNum');
  let pos=0, shown=-1;
  function radius(){ return Math.min(innerHeight*.42,520); }
  function drum(){
    const r=wrap.getBoundingClientRect(), total=r.height-innerHeight;
    const target=clamp(-r.top/total)*(N-1);
    pos+=(target-pos)*(reduce?1:.14);              // eased, so the drum keeps a little momentum
    const R=radius();
    items.forEach((el,i)=>{
      const a=(i-pos)*STEP;                         // angle of this course on the cylinder
      if(Math.abs(a)>95){ el.style.visibility='hidden'; return; }
      el.style.visibility='visible';
      el.style.transform=`translateZ(${-R}px) rotateX(${(-a).toFixed(2)}deg) translateZ(${R}px)`;
      const w=clamp(1-Math.abs(a)/(STEP*.9));        // 1 on the front, 0 one step away
      const c=grey.map((g,j)=>Math.round(g+(ink[j]-g)*w));
      el.style.color=`rgb(${c})`;
    });
    const cur=Math.round(pos);
    if(cur!==shown){ shown=cur; const el=items[cur];
      dLang.textContent=el.dataset.lang; dDates.textContent=el.dataset.dates; dNum.textContent=String(cur+1).padStart(2,'0')+' / '+String(N).padStart(2,'0'); }
    requestAnimationFrame(drum);
  }
  requestAnimationFrame(drum);

  // top bar background once the page scrolls
  const bar=document.querySelector('.bar');
  addEventListener('scroll',()=>bar.classList.toggle('solid',scrollY>40),{passive:true});
})();
