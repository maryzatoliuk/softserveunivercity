/* 01 — Fly-through
   Each .layer has data-d (depth). The camera moves along K: hold to read, then glide to the next stop. */
(function(){
  const PERSP=600;
  const barA=document.getElementById('barA'), hudN=document.getElementById('hudN');
  const layers=[...document.querySelectorAll('#fly .layer')].map(el=>({el,D:+el.dataset.d,x:0,y:0}));
  let prevD=null, lastT=null;
  const setBlur=(el,o,b)=>{const q=b>.12?Math.round(b*8)/8:0; if(q!==o.fq){o.fq=q; el.style.filter=q?`blur(${q}px)`:'none';}};


  // Centre the "O" on its ink box so the camera flies exactly through the counter
  function centreO(){
    const g=document.getElementById('oGlyph');
    const c=document.createElement('canvas').getContext('2d');
    c.font='640px "Azurio", Helvetica, Arial, sans-serif';
    const m=c.measureText('O');
    g.setAttribute('y',((m.actualBoundingBoxAscent-m.actualBoundingBoxDescent)/2).toFixed(1));
  }
  centreO(); if(document.fonts) document.fonts.ready.then(centreO);

  // Camera stops: d = depth, hold = pause to read, move = time to next stop
  const sine=k=>-(Math.cos(Math.PI*k)-1)/2;
  const quart=k=>k<.5?8*k*k*k*k:1-Math.pow(-2*k+2,4)/2;
  const K=[
    {d:-200, x:0, y:0, hold:1.1, move:1.8, ease:quart},
    {d:600,  x:0, y:0, hold:1.1, move:1.8, ease:quart},
    {d:1200, x:0, y:0, hold:1.2, move:2.6, ease:quart},  // dive through the O
    {d:2400, x:0, y:0, hold:1.3, move:5.2, ease:sine},   // long glide past Courses / Project-based / Complete
    {d:4400, x:0, y:0, hold:2.2, move:0}
  ];
  const TOTAL=K.reduce((s,k)=>s+k.hold+k.move,0);

  function camAt(time){
    let tt=time%TOTAL;
    for(let i=0;i<K.length;i++){
      const a=K[i];
      if(tt<a.hold) return {d:a.d,x:a.x,y:a.y,i};
      tt-=a.hold;
      if(tt<a.move){ const b=K[i+1], k=a.ease(tt/a.move);
        return {d:a.d+(b.d-a.d)*k, x:a.x+(b.x-a.x)*k, y:a.y+(b.y-a.y)*k, i}; }
      tt-=a.move;
    }
    return {d:K[0].d,x:0,y:0,i:0};
  }

  function tick(){
    const t=window.__t||0, dt=lastT===null?0:Math.max(0,t-lastT); lastT=t;
    const c=camAt(t);
    const v=(prevD===null||dt===0)?0:Math.abs(c.d-prevD)/dt; prevD=c.d;
    for(const L of layers){
      const tz=c.d-L.D;
      if(tz>PERSP-25 || tz<-720){ L.el.style.visibility='hidden'; continue; }
      L.el.style.visibility='visible';
      const op=tz<-160?Math.pow((tz+720)/560,1.6):1;          // distant layers fade in like haze
      L.el.style.opacity=op.toFixed(3);
      L.el.style.transform=`translate3d(${L.x-c.x}px,${L.y-c.y}px,${tz.toFixed(1)}px)`;
      const b=(window.__blur!==false&&dt>0&&tz>80)?Math.min(3,v/3200*(tz-80)/90):0;   // motion blur near the lens
      setBlur(L.el,L,b);
    }
    barA.style.width=((t%TOTAL)/TOTAL*100)+'%';
    hudN.textContent=String(c.i+1).padStart(2,'0')+' / 05';
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
})();
