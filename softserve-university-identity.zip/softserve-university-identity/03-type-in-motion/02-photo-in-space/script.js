initPhotoFrame({frame:'photoFrame',stops:[[-11,5],[10,-4],[6,6],[-8,-5]],tiltX:14,tiltZ:-5});
