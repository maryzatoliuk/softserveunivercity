/* Type in Motion — website hero, "tunnel of type"
   1. Intro poster: four cubes fill the screen. Each turns over (top face comes to the front), then the four
      swing open like doors. While nobody scrolls this repeats every 16 s; every loop starts where the last ended.
   2. Tunnel: a six-sided tunnel built from CSS 3D planes. The camera flies down it forever (segments are
      recycled from the near end to the far end, hidden in the fog) and the tunnel slowly turns.
   3. Scroll: the camera speeds up, the tunnel turns further and the headline at the end of the tunnel
      grows until it fills the screen — and opens onto the course list. */
(function(){
  const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const clamp=v=>v<0?0:v>1?1:v, ease=k=>k<.5?4*k*k*k:1-Math.pow(-2*k+2,3)/2, smooth=k=>k*k*(3-2*k);
  const hero=document.getElementById('hero'), world=document.getElementById('world'), endwall=document.getElementById('endwall');
  const hint=document.querySelector('.scroll-hint'), bar=document.getElementById('bar');

  // ---------- tunnel ----------
  const COURSES=['Основи тестування<br>та IT','Основи тестування<br>та автоматизації','Основи тестування<br>та FrontEnd','Основи тестування<br>та LLM','Основи тестування<br>Java Script','Основи тестування<br>AI'];
  const NUMS=[['36 000+','graduates’ community'],['70+','IT courses'],['60+','learning solutions']];
  const enroll='Enroll now! Enroll now!<br>'.repeat(6);
  const KINDS=['type','course','photo','type','logo','course','photo-blue'];
  const poster=(kind,s,k)=>{
    const n=(s+k)%6;
    if(kind==='type')   return ['w-type',`<p>${enroll}</p>`];
    if(kind==='course') return ['w-course',`<span class="mono">Project-based program · ${String(n+1).padStart(2,'0')}</span><h3>${COURSES[n]}</h3>`];
    if(kind==='photo')  return ['w-photo',`<div class="fig"></div><b>IT</b>`];
    if(kind==='photo-blue') return ['w-photo blue',`<div class="fig"></div>`];
    const [b,l]=NUMS[n%3]; return [n%2?'w-logo orange':'w-logo',`<img src="../../assets/softserve-university-logo.png" alt=""><b>${b}</b><span class="mono">${l}</span>`];
  };

  let A, SIDE, L, D; const SEGS=12, segs=[];
  function build(){
    world.innerHTML=''; segs.length=0;
    A=Math.round(Math.max(innerWidth*.39,innerHeight*.62));        // distance from the axis to each wall
    SIDE=Math.ceil(2*A/Math.sqrt(3))+2; L=Math.round(SIDE*.8); D=L*SEGS;
    for(let s=0;s<SEGS;s++){
      const seg=document.createElement('div'); seg.className='seg'; world.appendChild(seg);
      const fogs=[];
      for(let k=0;k<6;k++){
        const [cls,html]=poster(KINDS[(s*5+k*3)%KINDS.length],s,k);
        const w=document.createElement('div'); w.className='wall '+cls; w.innerHTML=html+'<i></i>';
        w.style.cssText=`left:${-SIDE/2}px;top:${-L/2}px;width:${SIDE}px;height:${L}px;transform:rotateZ(${60*k}deg) translateY(${A}px) rotateX(90deg)`;
        seg.appendChild(w); fogs.push(w.lastChild);
      }
      segs.push({el:seg,fogs,s,fog:-1});
    }
  }
  build(); addEventListener('resize',()=>{ build(); sizeDoors(); });

  // ---------- intro poster (cubes + doors) ----------
  const doors=[...document.querySelectorAll('.door')].map(d=>{
    const cube=d.querySelector('.cube'), sides=[...cube.querySelectorAll('.side')];
    // four faces round the cube: front, top, front again, top again → the cube can keep turning forward forever
    const f2=sides[0].cloneNode(true), t2=sides[1].cloneNode(true); cube.append(f2,t2);
    const all=[sides[0],sides[1],f2,t2]; all.forEach(s=>s.appendChild(document.createElement('i')));
    return {d,cube,all,q:+d.dataset.q};
  });
  function sizeDoors(){ const h=innerHeight/2; doors.forEach(o=>o.all.forEach((s,j)=>s.style.transform=`rotateX(${90*j}deg) translateZ(${h/2}px)`)); }
  sizeDoors();

  const LOOP=16;
  let t=0, last=null, visible=true, sp=0, sps=0;
  addEventListener('message',e=>{ const m=e.data||{}; if(m.kt==='visible') visible=!!m.value; });
  window.__setT=v=>{t=v;}; window.__sps=()=>sps;

  function frame(now){
    if(last===null) last=now; const dt=Math.min((now-last)/1000,.05); last=now;
    if(visible&&!reduce) t+=dt;
    const r=hero.getBoundingClientRect();
    sp=clamp(-r.top/(r.height-innerHeight)); sps+=(sp-sps)*(1-Math.exp(-dt*7)); if(Math.abs(sp-sps)<1e-4) sps=sp;   // time-based easing: same feel at any frame rate

    // tunnel: fly forward + scroll boost, turn slowly
    const camZ=t*260+sps*5200, spin=t*6+sps*150;
    world.style.transform=`rotateZ(${spin.toFixed(2)}deg)`;
    segs.forEach(g=>{
      let rel=((g.s*L-camZ)%D+D)%D; if(rel>D-.8*L) rel-=D;          // recycle: the segment that passed the camera jumps to the far end
      g.el.style.transform=`translateZ(${(-rel).toFixed(1)}px)`;
      const fog=clamp((rel-D*.32)/(D*.55)).toFixed(2);
      if(fog!==g.fog){ g.fog=fog; g.fogs.forEach(f=>f.style.opacity=fog); }
    });

    // headline at the end of the tunnel: grows until it fills the screen
    const e=Math.pow(sps,2.2), sc=1+e*Math.max(innerWidth/560,innerHeight/340)*1.05;
    endwall.style.transform=`scale(${sc.toFixed(4)})`;
    const fade=(1-smooth(clamp((sps-.72)/.22))).toFixed(3);                // its text dissolves as it fills the screen → seamless hand-over to the courses
    if(endwall.__f!==fade){ endwall.__f=fade; [...endwall.children].forEach(c=>c.style.opacity=fade); }
    endwall.style.boxShadow=`0 0 0 1px rgba(0,0,0,${(.06*(1-sps)).toFixed(3)}),0 30px 80px rgba(0,0,0,${(.45*(1-sps)).toFixed(3)})`;
    bar.classList.toggle('ink',sps>.72);
    hint.style.opacity=(.85*(1-clamp(sps*8))).toFixed(2);

    // intro poster: turn, open, hold, close — repeats while the page is at the top
    const n=Math.floor(t/LOOP), u=t-n*LOOP;
    const scrolled=clamp(sps*25);
    doors.forEach(o=>{
      const turn=ease(clamp((u-1-o.q*.12)/1.1));
      const open=Math.max(ease(clamp((u-2.5-o.q*.08)/1.3))*(1-ease(clamp((u-14.4-(3-o.q)*.08)/1.2))), scrolled);
      const ang=(n+turn)*90;
      o.cube.style.transform=`translateZ(${(-innerHeight/4).toFixed(1)}px) rotateX(${(-ang).toFixed(2)}deg)`;
      o.all.forEach((s,j)=>{ const rel=Math.abs(((j*90-ang)%360+540)%360-180);   // 0 = facing us, 90 = edge-on
        s.lastChild.style.opacity=(.55*Math.min(rel,90)/90).toFixed(3); });
      const side=(o.q%2===0)?1:-1;
      o.d.style.transform=`rotateY(${(side*96*open).toFixed(2)}deg)`;
      o.d.style.visibility=open>.995?'hidden':'visible';
    });
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // top bar turns light once the courses scroll under it
  const courses=document.getElementById('courses');
  addEventListener('scroll',()=>bar.classList.toggle('solid',courses.getBoundingClientRect().top<70),{passive:true});

  // course cards flip in row by row
  const cards=[...document.querySelectorAll('.card')];
  const io=new IntersectionObserver(es=>es.forEach(en=>{
    if(!en.isIntersecting) return; const i=cards.indexOf(en.target);
    en.target.style.transitionDelay=((i%3)*.09+Math.floor(i/3)*.05)+'s'; en.target.classList.add('in'); io.unobserve(en.target);
  }),{threshold:.15});
  cards.forEach(c=>io.observe(c));
})();
