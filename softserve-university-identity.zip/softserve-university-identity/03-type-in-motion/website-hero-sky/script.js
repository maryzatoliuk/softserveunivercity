/* Type in Motion — website hero, "photo in space: sky" version (like story variant 04)
   Layers: background photo → "Shaping" (behind the person) → cut-out person → headline lines in front.
   They share one camera; their depth (data-z) makes them slide at different speeds, so the person stands
   between the words. Lines swing in on load; the pointer and the scroll move the camera. */
(function(){
  const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const hero=document.getElementById('hero'), layers=[...document.querySelectorAll('.layer')];
  const lines=[...document.querySelectorAll('.hl')], fig=document.querySelector('.figure');
  layers.forEach(l=>l.z=+l.dataset.z);
  const clamp=v=>v<0?0:v>1?1:v, inOut=k=>k<.5?4*k*k*k:1-Math.pow(-2*k+2,3)/2;
  const T0=performance.now();
  let px=0,py=0,mx=0,my=0,sp=0;
  addEventListener('pointermove',e=>{px=e.clientX/innerWidth-.5; py=e.clientY/innerHeight-.5;},{passive:true});
  function frame(now){
    const t=Math.max(0,(now-T0)/1000);
    mx+=(px-mx)*.05; my+=(py-my)*.05;
    const r=hero.getBoundingClientRect(); sp+=(clamp(-r.top/(innerHeight*.5))-sp)*.12;
    const yaw=reduce?0:(-6*mx+2.2*Math.sin(t*.25)), pitch=reduce?0:(4*my+1.2*Math.sin(t*.19)-6*sp);
    const cam=`translateZ(${(sp*60).toFixed(1)}px) rotateX(${pitch.toFixed(2)}deg) rotateY(${yaw.toFixed(2)}deg)`;
    layers.forEach(l=>l.style.transform=`${cam} translateZ(${l.z}px)`);
    if(fig&&!reduce) fig.style.transform=`translateY(${(4*Math.sin(t*1.2)).toFixed(1)}px)`;   // hangs in the jump
    lines.forEach((el,i)=>{
      const k=reduce?1:inOut(clamp((t-.3-i*.16)/1.1));
      el.style.transform=`rotateY(${(70*(1-k)).toFixed(2)}deg)`;                          // turns in from depth (behind)
      el.style.opacity=(k<.2?k/.2:1).toFixed(3);
    });
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // top bar gets a background once the courses scroll under it
  const bar=document.querySelector('.bar'), courses=document.getElementById('courses');
  addEventListener('scroll',()=>bar.classList.toggle('solid',courses.getBoundingClientRect().top<70),{passive:true});

  // courses: flip-in, row by row
  const cards=[...document.querySelectorAll('.card')];
  const io=new IntersectionObserver(es=>es.forEach(e=>{
    if(!e.isIntersecting) return;
    const i=cards.indexOf(e.target);
    e.target.style.transitionDelay=((i%3)*.09+Math.floor(i/3)*.05)+'s';
    e.target.classList.add('in'); io.unobserve(e.target);
  }),{threshold:.15});
  cards.forEach(c=>io.observe(c));

  // cards lean slightly towards the cursor
  cards.forEach(c=>{
    c.addEventListener('pointermove',e=>{
      if(!c.classList.contains('in')) return;
      const r=c.getBoundingClientRect(), x=(e.clientX-r.left)/r.width-.5, y=(e.clientY-r.top)/r.height-.5;
      c.style.transitionDelay='0s';
      c.style.transform=`rotateX(${(-y*8).toFixed(2)}deg) rotateY(${(x*10).toFixed(2)}deg) translateZ(0)`;
    });
    c.addEventListener('pointerleave',()=>{ c.style.transform=''; });
  });
})();
