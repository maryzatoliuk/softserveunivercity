/* ---------- Ж. Atrium camera ---------- */
(function(){
  const cam=document.getElementById('cam2'), grain=document.getElementById('grain2'), bar=document.getElementById('barA2');
  const A=document.getElementById('planeA');
  // planes live in world space: fixed position and angle, not glued to any wall
  A.style.transform='translate3d(54px,110px,-30px) rotateY(-28deg) rotateX(5deg) rotateZ(-2deg)';
  let n=0;
  function loop(){
    const t=window.__t||0, T=12, k=(t%T)/T, w=Math.sin(2*Math.PI*k);
    // the camera walks sideways and turns towards the text, like a handheld AR shot
    const ry=6.5*w+.3*Math.sin(t*2.1)+.18*Math.sin(t*3.7);
    const rx=2+2*Math.sin(t*.4)+.25*Math.sin(t*2.6);
    const tx=-30*w+1.6*Math.sin(t*3.3), ty=8*Math.sin(t*.5)+2*Math.sin(t*2.9);
    const tz=40+50*Math.cos(2*Math.PI*k);
    cam.style.transform=`translate3d(${tx.toFixed(1)}px,${ty.toFixed(1)}px,${tz.toFixed(1)}px) rotateX(${rx.toFixed(2)}deg) rotateY(${ry.toFixed(2)}deg)`;
    bar.style.width=(k*100)+'%';
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
  const ib=document.getElementById('integ'); if(ib) ib.onclick=e=>{const f=document.getElementById('atriumFrame');const raw=f.classList.toggle('raw');e.target.textContent=raw?'Світло й зерно: вимк.':'Світло й зерно: увімк.';e.target.classList.toggle('on',!raw);};
})();
