# SoftServe University — New identity (landing presentation)

Open `index.html` in a browser. The first screen shows the three directions; each one has its own section below.

```
softserve-university-identity/
├── index.html            landing: hero with the 3 directions, a section per direction, side by side
├── landing.css           landing styles (Azurio + Roboto Mono, SoftServe University logo)
├── landing.js            nav, hero preview scaling, lazy-loading / pausing of animations
├── assets/               fonts and logo for the landing
├── 01-cards/             Cards — static posts, cube + flipping-post motion, flipping-sections website
├── 02-space-mission/     Space Mission — static posts, website-mission/ (black-to-paper landing)
├── 03-type-in-motion/    Type in Motion — kinetic typography: 8 stories + 5 website heroes (incl. tunnel of type)
└── website-landings/     website landing options used by Cards and Space Mission
```

Cards and Space Mission show static posts and website landings (options from `website-landings/platform-options.html`).
Type in Motion embeds every variant live from `03-type-in-motion/` — edits there show up on the landing automatically.
If a browser blocks local files, run `npx serve .` in this folder and open the address it prints.
