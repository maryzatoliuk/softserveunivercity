/* SoftServe University — identity concepts landing */
(function(){
  // nav: border on scroll + highlight the current concept
  const nav=document.querySelector('.nav'), links=[...document.querySelectorAll('.nav-links a')];
  addEventListener('scroll',()=>nav.classList.toggle('scrolled',scrollY>10),{passive:true});
  const secIO=new IntersectionObserver(es=>es.forEach(e=>{
    if(e.isIntersecting) links.forEach(a=>a.classList.toggle('on',a.getAttribute('href')==='#'+e.target.id));
  }),{rootMargin:'-45% 0px -50% 0px'});
  document.querySelectorAll('.concept').forEach(s=>secIO.observe(s));

  // hero card 3: scale the live 320×568 story to fill the card
  const live=document.querySelector('.card-visual.live'), heroFrame=live&&live.querySelector('iframe');
  function fit(){
    if(!live) return;
    const r=live.getBoundingClientRect(), s=Math.max(r.width/320,r.height/568);
    heroFrame.style.transform=`translate(-50%,-50%) scale(${s.toFixed(4)})`;
  }
  fit(); addEventListener('resize',fit);

  // website mock: render the 1440×900 page and scale it to the browser window
  const view=document.querySelector('.browser-view'), site=document.getElementById('siteFrame');
  function fitSite(){ if(view) site.style.transform=`scale(${(view.clientWidth/1440).toFixed(4)})`; }
  fitSite(); addEventListener('resize',fitSite);

  // hero options A / B / C share one browser window
  const notes={
    'website-hero/':'Scroll inside the window: the panel straightens, the headline drifts, course cards flip in.',
    'website-hero-angle/':'The camera orbits a flat poster, left/right and up/down; the headline floats on its own plane. Move the pointer to steer it.',
    'website-hero-drum/':'Scroll inside the window past the headline: the course list turns like a drum — the course in front is black, the rest roll away in grey.',
    'website-hero-tunnel/':'A poster of four cubes turns and swings open onto a tunnel of type. Scroll inside the window: the camera speeds down the tunnel and flies into the headline.',
    'website-hero-sky/':'Photo layers with the headline woven around the person: “Shaping” behind, the rest in front. Move the pointer to shift the camera.'};
  const tabs=[...document.querySelectorAll('#heroTabs button')], open=document.getElementById('heroOpen'), note=document.getElementById('heroNote');
  tabs.forEach(b=>b.addEventListener('click',()=>{
    tabs.forEach(x=>x.classList.toggle('on',x===b));
    site.src=b.dataset.src; open.href=b.dataset.src;
    const key=Object.keys(notes).find(k=>b.dataset.src.includes(k+'index')); note.textContent=notes[key]||'';
  }));

  // Cards / Space Mission website landings: one browser window per concept, tabs switch the option
  const scaleAll=()=>document.querySelectorAll('.opt-frame').forEach(f=>{ f.style.transform=`scale(${(f.parentElement.clientWidth/1440).toFixed(4)})`; f.style.transformOrigin='0 0'; f.style.position='absolute'; f.style.left='0'; f.style.top='0'; f.style.border='0'; });
  scaleAll(); addEventListener('resize',scaleAll);
  document.querySelectorAll('.opt-tabs').forEach(tabsEl=>{
    const g=tabsEl.dataset.group, frame=document.querySelector(`.opt-frame[data-group="${g}"]`), open=document.querySelector(`.opt-open[data-group="${g}"]`);
    const note=document.querySelector(`.opt-note[data-group="${g}"]`), OPT_NOTE='Each option opens with its loading screen; scroll inside the window to see the course cards.';
    const btns=[...tabsEl.querySelectorAll('button')];
    btns.forEach(b=>b.addEventListener('click',()=>{
      btns.forEach(x=>x.classList.toggle('on',x===b));
      if(b.dataset.src){                     // a stand-alone page (e.g. Cards · Flipping sections)
        frame.src=b.dataset.src; open.href=b.dataset.open||b.dataset.src;
      }else{
        const n=b.dataset.opt;
        frame.src=`website-landings/platform-options.html?embed&o=${n}#option-${n}`;   // new query = fresh load with that option
        open.href=`website-landings/platform-options.html#option-${n}`;
      }
      if(note) note.textContent=b.dataset.note||OPT_NOTE;
    }));
  });

  // side-by-side: scale the live story to fit its tile (with a little air around it)
  const cmpLive=document.querySelector('.cmp-visual.live'), cmpFrame=cmpLive&&cmpLive.querySelector('iframe');
  function fitCmp(){ if(!cmpLive) return; const r=cmpLive.getBoundingClientRect(), s=Math.min((r.width-28)/320,(r.height-28)/568);
    cmpFrame.style.transform=`translate(-50%,-50%) scale(${s.toFixed(4)})`; }
  fitCmp(); addEventListener('resize',fitCmp);

  // concept 3 stories: load when near the screen, animate only while visible (keeps the page smooth)
  const send=(f,kt,value)=>f.contentWindow&&f.contentWindow.postMessage({kt,value},'*');
  const frames=[...document.querySelectorAll('iframe')];
  const io=new IntersectionObserver(es=>es.forEach(e=>{
    const f=e.target;
    if(e.isIntersecting&&f.dataset.src&&!f.src){ f.src=f.dataset.src; }
    send(f,'visible',e.isIntersecting);
  }),{rootMargin:'300px 0px'});
  frames.forEach(f=>{
    io.observe(f);
    f.addEventListener('load',()=>{
      const r=f.getBoundingClientRect(); send(f,'visible',r.bottom>-300&&r.top<innerHeight+300);
    });
  });
})();
