/* Space Mission — "Mission" landing
   · the black veil at the top of the screen thins out as you scroll, so the black "drains away" upwards
   · telemetry: live date card, mission clock, scrambled mono labels, counters
   · dot-matrix headlines drawn on canvas (5×7 LED font) — unlit dots stay faintly visible
   · callout lines that draw themselves on the anatomy section */
(function(){
  const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const clamp=v=>v<0?0:v>1?1:v;
  const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];

  // ---------- live date + mission clock ----------
  const now=new Date(); $('#day').textContent=now.getDate(); $('#mon').textContent=now.toLocaleString('en',{month:'short'});
  const t0=performance.now(), clock=$('#clock');
  setInterval(()=>{ const s=Math.floor((performance.now()-t0)/1000), p=n=>String(n).padStart(2,'0');
    clock.textContent=`T+ ${p(Math.floor(s/3600))}:${p(Math.floor(s/60)%60)}:${p(s%60)}`; },1000);

  // ---------- scrambled labels ----------
  const GLYPHS='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/+-—·';
  function scramble(el){
    const final=el.dataset.final||(el.dataset.final=el.textContent); if(reduce){ el.textContent=final; return; }
    const start=performance.now(), D=700;
    (function step(n){ const k=clamp((n-start)/D);
      el.textContent=[...final].map((c,i)=>c===' '||i/final.length<k?c:GLYPHS[(Math.random()*GLYPHS.length)|0]).join('');
      if(k<1) requestAnimationFrame(step); })(start);
  }

  // ---------- dot-matrix (5×7) ----------
  const F={A:'01110100011000111111100011000110001',B:'11110100011000111110100011000111110',C:'01110100011000010000100001000101110',D:'11110100011000110001100011000111110',
    E:'11111100001000011110100001000011111',F:'11111100001000011110100001000010000',G:'01110100011000010111100011000101111',H:'10001100011000111111100011000110001',
    I:'01110001000010000100001000010001110',J:'00111000100001000010000101001001100',K:'10001100101010011000101001001010001',L:'10000100001000010000100001000011111',
    M:'10001110111010110101100011000110001',N:'10001100011100110101100111000110001',O:'01110100011000110001100011000101110',P:'11110100011000111110100001000010000',
    Q:'01110100011000110001101011001001101',R:'11110100011000111110101001001010001',S:'01111100001000001110000010000111110',T:'11111001000010000100001000010000100',
    U:'10001100011000110001100011000101110',V:'10001100011000110001100010101000100',W:'10001100011000110101101011010101010',X:'10001100010101000100010101000110001',
    Y:'10001100010101000100001000010000100',Z:'11111000010001000100010001000011111',
    '0':'01110100011001110101110011000101110','1':'00100011000010000100001000010001110','2':'01110100010000100010001000100011111','3':'11111000100010000010000011000101110',
    '4':'00010001100101010010111110001000010','5':'11111100001111000001000011000101110','6':'00110010001000011110100011000101110','7':'11111000010001000100010000100001000',
    '8':'01110100011000101110100011000101110','9':'01110100011000101111000010001001100','.':'00000000000000000000000000110001100','-':'00000000000000011111000000000000000',
    '+':'00000001000010011111001000010000000',':':'00000011000110000000011000110000000','/':'00001000010001000100010001000010000',' ':'00000000000000000000000000000000000'};
  const mats=[];
  function setupMatrix(cv){
    const text=cv.dataset.text.toUpperCase(), cols=text.length*6-1;
    const m={cv,text,cols,lit:[],shown:false,start:0};
    const dots=[]; [...text].forEach((ch,ci)=>{ const g=F[ch]||F[' ']; for(let r=0;r<7;r++) for(let c=0;c<5;c++) dots.push({x:ci*6+c,y:r,on:g[r*5+c]==='1',d:Math.random()}); });
    m.dots=dots; mats.push(m); sizeMatrix(m); return m;
  }
  function sizeMatrix(m){
    const w=m.cv.clientWidth, cell=w/m.cols, h=Math.round(cell*7), dpr=Math.min(2,devicePixelRatio||1);
    m.cell=cell; m.cv.style.height=h+'px'; m.cv.width=Math.round(w*dpr); m.cv.height=Math.round(h*dpr); m.dpr=dpr; drawMatrix(m,performance.now());
  }
  function drawMatrix(m,now){
    const ctx=m.cv.getContext('2d'), c=m.cell*m.dpr, r=c*.36, k=m.shown?(reduce?1:clamp((now-m.start)/1400)):0;
    const ink=getComputedStyle(m.cv).color;
    ctx.clearRect(0,0,m.cv.width,m.cv.height); ctx.fillStyle=ink;
    for(const d of m.dots){
      const lit=d.on&&d.d<k;
      ctx.globalAlpha=lit?1:.09;
      ctx.beginPath(); ctx.arc((d.x+.5)*c,(d.y+.5)*c,r,0,Math.PI*2); ctx.fill();
    }
    ctx.globalAlpha=1; return k<1;
  }
  $$('canvas.matrix').forEach(setupMatrix);

  // dotted progress bars under the numbers
  const bars=$$('canvas.bar-dots').map(cv=>({cv,fill:+cv.dataset.fill,shown:false,start:0}));
  function drawBar(b,now){
    const dpr=Math.min(2,devicePixelRatio||1), w=b.cv.clientWidth, h=b.cv.clientHeight;
    if(b.cv.width!==Math.round(w*dpr)){ b.cv.width=Math.round(w*dpr); b.cv.height=Math.round(h*dpr); }
    const ctx=b.cv.getContext('2d'), step=12*dpr, rows=2, cols=Math.floor(b.cv.width/step), k=b.shown?(reduce?1:clamp((now-b.start)/1600)):0;
    ctx.clearRect(0,0,b.cv.width,b.cv.height);
    for(let y=0;y<rows;y++) for(let x=0;x<cols;x++){
      const on=x/cols<b.fill*(1-Math.pow(1-k,3));
      ctx.globalAlpha=on?1:.14; ctx.fillStyle=on&&x===Math.floor(b.fill*cols*(1-Math.pow(1-k,3)))-1?'#FE8D6B':'#0e0e0e';
      ctx.beginPath(); ctx.arc((x+.5)*step,(y+.5)*step,step*.3,0,Math.PI*2); ctx.fill();
    }
    ctx.globalAlpha=1; return k<1;
  }

  // ---------- counters ----------
  function count(el){ const to=+el.dataset.count, suf=el.dataset.suffix||'', start=performance.now(), D=reduce?0:1600;
    (function step(n){ const k=D?clamp((n-start)/D):1, v=Math.round(to*(1-Math.pow(1-k,4)));
      el.textContent=v.toLocaleString('en').replace(/,/g,' ')+suf; if(k<1) requestAnimationFrame(step); })(start); }

  // ---------- hero corner marks ----------
  function marks(){
    const svg=$('.marks'), w=svg.clientWidth, h=svg.clientHeight, g=240, s=9; let d='';
    for(let x=g;x<w;x+=g) for(let y=g/2;y<h;y+=g) d+=`M${x-s} ${y}h${s}v${s} `;
    svg.innerHTML=`<path d="${d}"/>`;
  }
  marks();

  // ---------- anatomy callouts ----------
  const lines=$('#lines'), parts=$$('.parts li');
  function layoutParts(){
    const rig=$('.rig'), sx=rig.clientWidth/1360, sy=rig.clientHeight/820;
    let html='';
    parts.forEach((li,i)=>{
      const x=+li.dataset.x, y=+li.dataset.y; li.style.top=(y*sy-30)+'px';
      const lx=li.offsetLeft/sx-14;
      const d=`M${x} ${y} L${x+60} ${y-40} L${lx} ${y-40}`;
      html+=`<path class="halo" d="${d}" data-i="${i}" vector-effect="non-scaling-stroke"/><path d="${d}" data-i="${i}" vector-effect="non-scaling-stroke"/><circle class="ring" cx="${x}" cy="${y}" r="9" vector-effect="non-scaling-stroke"/><circle class="core" cx="${x}" cy="${y}" r="3.5"/>`;
    });
    lines.innerHTML=html;
    lines.querySelectorAll('path').forEach(p=>{ const L=p.getTotalLength(); p.style.strokeDasharray=L; p.style.strokeDashoffset=lines.dataset.on?0:L; p.style.transition='stroke-dashoffset 1s cubic-bezier(.2,.7,.2,1)'; p.style.transitionDelay=(+p.dataset.i*.18)+'s'; });
  }
  layoutParts();

  // ---------- reveal on view ----------
  const io=new IntersectionObserver(es=>es.forEach(e=>{
    if(!e.isIntersecting) return; const el=e.target; io.unobserve(el);
    if(el.matches('[data-scramble]')) scramble(el);
    if(el.matches('canvas.matrix')){ const m=mats.find(m=>m.cv===el); m.shown=true; m.start=performance.now(); anim(); }
    if(el.matches('canvas.bar-dots')){ const b=bars.find(b=>b.cv===el); b.shown=true; b.start=performance.now(); anim(); }
    if(el.matches('[data-count]')) count(el);
    if(el===lines){ lines.dataset.on=1; lines.querySelectorAll('path').forEach(p=>p.style.strokeDashoffset=0); parts.forEach((li,i)=>setTimeout(()=>li.classList.add('in'),300+i*180)); }
  }),{threshold:.25});
  $$('[data-scramble],canvas.matrix,canvas.bar-dots,[data-count]').forEach(el=>io.observe(el)); io.observe(lines);

  let animating=false;
  function anim(){ if(animating) return; animating=true; requestAnimationFrame(function step(n){
    let more=false; mats.forEach(m=>{ if(m.shown&&drawMatrix(m,n)) more=true; }); bars.forEach(b=>{ if(drawBar(b,n)) more=true; });
    if(more) requestAnimationFrame(step); else animating=false; }); }
  bars.forEach(b=>drawBar(b,0));

  // ---------- scroll: veil drains away, hero parallax, UI turns light ----------
  const veil=$('#veil'), bar=$('#bar'), tele=$('#tele'), obj=$('#obj'), hl=$$('.headline span');
  function onScroll(){
    const y=scrollY, H=innerHeight;
    veil.style.opacity=(1-clamp(y/(H*.85))).toFixed(3);
    const light=y>H*.72; bar.classList.toggle('light',light); tele.classList.toggle('light',light);
    if(!reduce){
      const k=clamp(y/H);
      obj.style.transform=`translateY(${(y*.3).toFixed(1)}px) scale(${(1-.1*k).toFixed(4)})`;   // origin on the right edge → the cut side stays off-screen
      hl.forEach((s,i)=>s.style.transform=`translateX(${(y*[.05,-.03,.08][i]).toFixed(1)}px)`);   // lines drift apart a little
    }
  }
  addEventListener('scroll',onScroll,{passive:true}); onScroll();

  addEventListener('resize',()=>{ mats.forEach(sizeMatrix); bars.forEach(b=>{b.cv.width=0; drawBar(b,performance.now());}); marks(); layoutParts(); });
})();
