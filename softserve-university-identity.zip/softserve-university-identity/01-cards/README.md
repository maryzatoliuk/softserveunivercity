Cards — concept 1 materials
posts/                 static posts
motion-cube/           A · photo card flips right to left (img/ holds the shared post images)
motion-cube-vertical/  B · two cards flip down / up
motion-flip-posts/     C · a deck of posts: the front card flips over, the next comes forward
website-flip/          D · full-frame cards: each tips back while the next flips up (post animation; ?post = 16:9)
